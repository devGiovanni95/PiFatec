#include <stdio.h>
#include <stdlib.h>

int main(){
    int A; // %d ou %i- Inteiros
    printf("Digite um valor: ");
    scanf("%d", &A);
    printf("Valor digitado: %d", A);
    return 0;
}
