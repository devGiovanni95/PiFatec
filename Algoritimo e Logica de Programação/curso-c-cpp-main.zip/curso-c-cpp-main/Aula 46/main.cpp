#include <iostream>
#include <stdlib.h>

using namespace std;

int main(){
    //system("mode con cols=100 lines=15");
    //system("color a5");

    cout << "Hello world!" << endl;
    return 0;
}
