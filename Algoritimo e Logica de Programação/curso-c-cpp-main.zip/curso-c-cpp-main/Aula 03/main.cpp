#include <stdio.h>
#include <stdlib.h>

int main(){

    int ValorInteiro = 5; //int � para inteiros
                          // 4 bytes > 1 byte=8bits
                          // %d ou %i


    float ValorReal = 10.7; //float � para reais
                            //8bytes
                            //%f

    double ValorDouble = 10.7; //float � para reais
                               //16bytes
                               //%lf > long float

    char Letra1 = '5';  //char possui 1byte
    char Letra2 = 'b';
    char Letra3 = '*';  //%c

    bool Variavelbool1 = false;
    bool Variavelbool2 = true;






    return 0;
}
