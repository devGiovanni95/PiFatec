#include <iostream>
#include <stdlib.h>

using namespace std;

int main()
{
    cout << "\nMenu\n" << endl;
    cout << "Chamando modulo 1 ..."<<endl;

    system("\"C:\\Code Blocks\\modulo1\\bin\\debug\\modulo1.exe\" gtechinfor.com.br");
    cout<<"\n\n---------------------------\n\n";
    system("\"C:\\Code Blocks\\modulo1\\bin\\debug\\modulo1.exe\"");

    return 0;
}
