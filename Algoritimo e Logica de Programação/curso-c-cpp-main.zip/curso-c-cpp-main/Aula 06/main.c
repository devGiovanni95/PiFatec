#include <stdio.h>
#include <stdlib.h>

int main(){
    int A;

    for(A = 0 ; A < 100000; A++){
        printf("%d\n", A);
    }
    //A = A+1   ==   A++
    //C   > C++

    /*
    0
    1
    2
    3
    4
    5
    6
    7
    8
    9
    10
    */



    system("pause");
    return 0;
}
