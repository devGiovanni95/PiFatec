#include <iostream>

using namespace std;

int main(){
    char valor[10];

    cout << endl <<"Digite um valor: ";
    cin >> valor;

    cout << endl <<"Valor: " << valor << endl;

    do{


    }while(valor<20);


    while(valor<20){


    }

    if(valor<50) valor=100;
    else valor=10;


    if(valor<100 && valor>10){

    }

    if(valor<100){
        if(valor>10){

        }
    }


    return 0;
}
